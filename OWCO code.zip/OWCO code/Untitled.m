lu = [-100 * ones(1, 10); 100 * ones(1, 10)];
disp(lu);