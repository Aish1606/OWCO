
function Run_DE(Runs,fhd,C,problem_size,funcs,max_nfes,pop_size,optimum)

Rand_Seeds=load('input_data\Rand_Seeds.txt');
rng(0,'twister');
lt = 0; % low range temperature
ht = 100; % high range temperature
ll = -100; % low range location basse
hl = 100; %high range for location base
ld = 50; % low range density
hd = 500;% high range density
lp = 0; % low range depth
hp = 400;% high range depth
g = 9.8;
iws= 0.0000729; %initial windspeed
depth = randi([0 400]);% depth can be any random value between 0 to 400
threhold = 0.5;
initial_speed = 0;
theta = 90;
m = 0.4;
tidaleffect= 0.02;
% c = myrandom(a,b)
% ti = randi([20 100]);
% di = randi([20 100]);

ti = myrandomt(lt,ht); % function call for having range of random values between low and high temperature.
di = myrandomd(ld,hd); % function call for having range of random values between low and high density.
pi = myrandomp(lp,hp); % function call for having range of random values between low and high depth.
lb = myrandoml(ll,hl);  % function call for having range of random values between low and high locatin.

% disp('Enter if hemisphere is Northern or Southern  N For Northern  or S for Southern');
% prompt = 'Do you want S/N [S]: ';
% hemisphere = input(prompt,'s');
% if isempty(hemisphere)
%     hemisphere = 'Y';
% end
% 
% if (hemisphere == 'N' && depth < 400)
%     disp('ok N');
%     initial_speed = ((g*di)/(2*m*iws*sin(theta)));
% end
% if (hemisphere == 'S' && depth < 400)
%     disp('ok S');
%     initial_speed = ((g*di)/(2*m*iws*sin(-theta)));
% %     disp(initial_speed);
% end
disp(depth);
disp('F(j)   :    Min              Max             Mean              Median     Std                 ');
k=0;
for j=1:15
         
         for i=2:5
               Baseinitial_speed= initial_speed;
               WindSpeed = randi([0 1]);
               if (WindSpeed ==1)
               initial_speed= initial_speed + iws*.02;            
               else
               initial_speed= initial_speed - iws*.02;            
               end
               
                           
              Dens=di(i-1);
              if (di(i) > Dens)
              speed1=initial_speed - (di(i)*initial_speed)/di(i-1);
              else
              speed1=initial_speed + (di(i)*initial_speed)/di(i-1);
              end
             
              Deps=pi(i-1);
              if (pi(i) > Deps)
              speed2=speed1 + speed1*.002;
              else
              speed2=speed1 + speed1*.002;
              end
             
              Temp=ti(i-1);
              if (ti(i) > Temp)
              speed3=speed2 + speed2*.002;
              else
              speed3=speed2 + speed2*.002;
              end
              temp = fitness(Baseinitial_speed,initial_speed);
              if(temp==1);
        initial_speed=speed3;
              end
                 
         end
%disp(find(speed3==max(speed3)));
Bestspeed=sort(initial_speed);
lb1=min(Bestspeed);
lb2=Bestspeed(1);
lb11= std(lb1);
lb22= std(lb2);
r=randi([8 11]);

% if (hemisphere == 'N')
             lmplus1=lb11+(r*tidaleffect/m);
             fprintf('F(%d) %d    %d    %d    %d    %d\n',k,min(lmplus1),max(lmplus1), mean(lmplus1),median(lmplus1), std(lmplus1) );
%      end
% if (hemisphere == 'S')
%              lmplus2=lb11-(r*tidaleffect/m);
%              fprintf('F(%d) %d    %d    %d    %d    %d\n',k,min(lmplus2),max(lmplus2), mean(lmplus2),median(lmplus2), std(lmplus2) );
%      end
k=k+1;
%fprintf('F(%d) %d    %d    %d    %d    %d\n',k,min(speed3),max(speed3), mean(speed3),median(speed3), std(speed3) );
end



Alg_Name=[ 'OWCO_(' num2str(C(1)) num2str(C(2)) num2str(C(3)) ')'];

 F =0.50*ones(pop_size,problem_size);
 Cr=0.90*ones(pop_size,problem_size);
 
lu = [-100 * ones(1, problem_size); 100 * ones(1, problem_size)];

fprintf('Running %s algorithm on D= %d\n',Alg_Name, problem_size)

for n=0:15
    RecordFEsFactor(n+1) = round(problem_size^((n/5)-3)*max_nfes);
end

progress = numel(RecordFEsFactor);
val_2_reach = 10^(-8);


for func_no = funcs
    fprintf('\n-------------------------------------------------------\n')
    fprintf('Function = %d, Dimension size = %d\n', func_no, problem_size)
    allerrorvals = zeros(progress, Runs);
%     you can use parfor if you have MATLAB Parallel Computing Toolbox
%     parfor run_id = 1 : Runs
    for run_id = 1 : Runs-1
        run_seed=Rand_Seeds(mod(problem_size*func_no*Runs+run_id-Runs,length(Rand_Seeds)));
        rng(run_seed,'twister');
        Run_RecordFEsFactor=RecordFEsFactor;
        run_funcvals = [];
        %% Initialize the main population
        popold = repmat(lu(1, :), pop_size, 1) + rand(pop_size, problem_size) .* (repmat(lu(2, :) - lu(1, :), pop_size, 1));
        pop = popold; % the old population becomes the current population
        
        fitness1 = feval(fhd,pop',func_no,C);
        fitness1 = fitness1';
        nfes = pop_size;
        bsf_fit_var = min(fitness1);
        
        if(nfes>=Run_RecordFEsFactor(1))
            run_funcvals = [run_funcvals;bsf_fit_var];
            Run_RecordFEsFactor(1)=[];
        end
        
        %% main loop
        while nfes < max_nfes
            pop = popold; % the old population becomes the current population
            R = Gen_R(pop_size,3);
            r1=R(:,2);
            r2=R(:,3);
            r3=R(:,4);
            
            vi = pop(r1, :) + F .* (pop(r2, :) - pop(r3, :));
            
            vi = boundConstraint(vi, pop, lu);
            
            mask = rand(pop_size, problem_size) > Cr; % mask is used to indicate which elements of ui comes from the parent
            rows = (1 : pop_size)'; cols = floor(rand(pop_size, 1) * problem_size)+1; % choose one position where the element of ui doesn't come from the parent
            jrand = sub2ind([pop_size problem_size], rows, cols); mask(jrand) = false;
            ui = vi; ui(mask) = pop(mask);
            
            children_fitness = feval(fhd, ui', func_no,C);
            children_fitness = children_fitness';
            
            for i = 1 : pop_size
                nfes = nfes + 1;
                if children_fitness(i) < bsf_fit_var
                    bsf_fit_var = children_fitness(i);
                end
                if nfes > max_nfes; break; end
            end
            if(nfes>=Run_RecordFEsFactor(1))
                run_funcvals = [run_funcvals;bsf_fit_var];
                Run_RecordFEsFactor(1)=[];
            end
            
            [fitness1, I] = min([fitness1, children_fitness], [], 2);
            
            popold = pop;
            popold(I == 2, :) = ui(I == 2, :);
            
        end
        
        if(C(1)==1)
            run_funcvals=run_funcvals-optimum(func_no);
        end
        
        run_funcvals(run_funcvals<val_2_reach)=0;
        
        fprintf('%d th run, best-so-far error value = %1.8e\n', run_id , run_funcvals(end))
        
       lmplus3(:, run_id) = (run_funcvals);
        
    end %% end 1 run
    
    fprintf('min_funvals:\t%e\n',min(lmplus3(end,:)));
    fprintf('median_funvals:\t%e\n',median(lmplus3(end,:)));
    fprintf('mean_funvals:\t%e\n',mean(lmplus3(end,:)));
    fprintf('max_funvals:\t%e\n',max(lmplus3(end,:)));
    fprintf('std_funvals:\t%e\n',std(lmplus3(end,:)));
    
    file_name=sprintf('Results\\%s_%s_%s.txt',Alg_Name,int2str(func_no),int2str(problem_size));
    save(file_name, 'lmplus3', '-ascii');
    
end %% end 1 function run


end

function temperature = myrandomt(lt,ht)  % function definition for generating range of random values betwee low and high temperature.
   temperature = (ht-lt).*rand(1000,1) + lt;
end

function density = myrandomd(ld,hd)  % function definition for generating range of random values betwee low and high density.
   density = (hd-ld).*rand(1000,1) + ld;
end

function pressure = myrandomp(lp,hp)  % function definition for generating range of random values betwee low and high depth.
   pressure = (hp-lp).*rand(1000,1) + lp;
end

function location_base = myrandoml(ll,hl)  % function definition for generating range of random values betwee low and high temperature.
   location_base = (hl-ll).*rand(1000,1) + ll;
end

function fitnesseval = fitness(Baseinitial_speed,initial_speed)  % function definition for generating range of random values betwee low and high temperature.
   if((Baseinitial_speed-initial_speed)>0)
       fitnesseval = 1;
   else
       fitnesseval = 0;
   end
end
